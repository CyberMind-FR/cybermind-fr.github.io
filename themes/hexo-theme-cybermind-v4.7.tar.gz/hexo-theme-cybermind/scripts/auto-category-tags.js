/**
 * ═══════════════════════════════════════════════════════════════════════════
 * auto-category-tags.js - Gestion automatique des catégories et tags
 * ═══════════════════════════════════════════════════════════════════════════
 * 
 * Ce script Hexo:
 * 1. Détecte automatiquement la catégorie depuis le chemin OU le front matter
 * 2. Normalise les tags (stockés dans normalized_tags)
 * 3. Fournit des helpers pour les templates
 * 
 * Supporte:
 * - Articles dans source/_posts/ avec category/categories dans front matter
 * - Articles dans source/blog/{category}/ (détection par chemin)
 * - Système de catégories Hexo natif
 * 
 * Installation: Copier dans themes/cybermind/scripts/
 * 
 * ═══════════════════════════════════════════════════════════════════════════
 */

'use strict';

// ═══════════════════════════════════════════════════════════════════════════
// CONFIGURATION
// ═══════════════════════════════════════════════════════════════════════════

// Mapping des catégories avec leurs métadonnées
const CATEGORIES = {
  'cybersecurity': { name: 'Cybersécurité', slug: 'cybersecurity', color: '#00ff88', icon: '🛡️', description: 'Sécurité informatique, pentests, CrowdSec' },
  'embedded': { name: 'Embarqué', slug: 'embedded', color: '#ff6600', icon: '⚙️', description: 'ARM, Raspberry Pi, Armbian, U-Boot' },
  'linux': { name: 'Linux', slug: 'linux', color: '#ffcc00', icon: '🐧', description: 'Kernel, administration, open source' },
  'creative': { name: 'Créativité', slug: 'creative', color: '#ff6699', icon: '🎨', description: 'Art génératif, géométrie, musique' },
  'philosophy': { name: 'Philosophie', slug: 'philosophy', color: '#9966ff', icon: '🧘', description: 'Yi Jing, esprit critique, M00d' },
  'tutorials': { name: 'Tutoriels', slug: 'tutorials', color: '#66ccff', icon: '📖', description: 'Guides pratiques et how-to' },
};

// Aliases pour les catégories (permet plusieurs noms pour une même catégorie)
const CATEGORY_ALIASES = {
  'security': 'cybersecurity',
  'cyber': 'cybersecurity',
  'sécurité': 'cybersecurity',
  'securite': 'cybersecurity',
  'arm': 'embedded',
  'hardware': 'embedded',
  'raspberry': 'embedded',
  'raspberrypi': 'embedded',
  'raspberry-pi': 'embedded',
  'art': 'creative',
  'créativité': 'creative',
  'creativite': 'creative',
  'generative': 'creative',
  'yijing': 'philosophy',
  'yi-jing': 'philosophy',
  'philosophie': 'philosophy',
  'howto': 'tutorials',
  'guides': 'tutorials',
  'tutorial': 'tutorials',
  'tuto': 'tutorials',
};

// Tags à renommer (normalisation)
const TAG_RENAMES = {
  'CrowdSec': 'crowdsec',
  'OpenWrt': 'openwrt',
  'Armbian': 'armbian',
  'RaspberryPi': 'raspberry-pi',
  'Raspberry Pi': 'raspberry-pi',
  'raspberry pi': 'raspberry-pi',
  'Yi Jing': 'yi-jing',
  'yi jing': 'yi-jing',
  'yijing': 'yi-jing',
  'Yi-Jing': 'yi-jing',
  'JavaScript': 'javascript',
  'Python': 'python',
  'python3': 'python',
  'linux-kernel': 'kernel',
  'kernel-linux': 'kernel',
  'cyber-securite': 'cybersécurité',
  'cyber-security': 'cybersécurité',
};

// Tags à ignorer
const TAGS_TO_REMOVE = new Set([
  'misc', 'divers', 'other', 'test', 'draft', 'todo', 'wip', 'temp',
  'uncategorized', 'none', 'undefined', 'null', ''
]);

// ═══════════════════════════════════════════════════════════════════════════
// FONCTIONS UTILITAIRES
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Normalise un slug de catégorie
 */
function normalizeCategory(cat) {
  if (!cat) return null;
  
  const slug = String(cat).toLowerCase().trim();
  
  // Vérifier les aliases
  if (CATEGORY_ALIASES[slug]) {
    return CATEGORY_ALIASES[slug];
  }
  
  // Vérifier si c'est une catégorie connue
  if (CATEGORIES[slug]) {
    return slug;
  }
  
  return slug;
}

/**
 * Obtient les infos d'une catégorie
 */
function getCategoryInfo(slug) {
  const normalized = normalizeCategory(slug);
  if (normalized && CATEGORIES[normalized]) {
    return { ...CATEGORIES[normalized], slug: normalized };
  }
  return { 
    name: slug || 'Catégorie', 
    slug: slug || 'default', 
    color: '#888888', 
    icon: '📁',
    description: ''
  };
}

/**
 * Extrait la catégorie depuis le chemin du fichier
 */
function getCategoryFromPath(filePath) {
  if (!filePath) return null;
  
  const parts = filePath.replace(/\\/g, '/').split('/');
  
  for (let i = 0; i < parts.length - 1; i++) {
    const part = parts[i].toLowerCase();
    
    // Si on trouve "blog", la catégorie est le dossier suivant
    if (part === 'blog' && parts[i + 1]) {
      const nextPart = parts[i + 1].toLowerCase();
      if (!nextPart.endsWith('.md')) {
        return normalizeCategory(nextPart);
      }
    }
    
    // Vérifier directement dans les catégories connues
    const normalized = normalizeCategory(part);
    if (normalized && CATEGORIES[normalized]) {
      return normalized;
    }
  }
  
  return null;
}

/**
 * Extrait la catégorie d'un post (depuis front matter ou chemin)
 */
function getPostCategory(post) {
  // 1. Depuis le champ category (singulier) - priorité haute
  if (post.category && typeof post.category === 'string') {
    return normalizeCategory(post.category);
  }
  
  // 2. Depuis le champ categories (Hexo natif)
  if (post.categories) {
    let cats = [];
    
    // Convertir en array si c'est un objet Hexo
    if (typeof post.categories.toArray === 'function') {
      cats = post.categories.toArray();
    } else if (Array.isArray(post.categories)) {
      cats = post.categories;
    } else if (typeof post.categories.forEach === 'function') {
      post.categories.forEach(function(c) { cats.push(c); });
    }
    
    if (cats.length > 0) {
      const firstCat = cats[0];
      // Gérer les différents formats possibles
      let catName = '';
      if (typeof firstCat === 'string') {
        catName = firstCat;
      } else if (firstCat && firstCat.name) {
        catName = firstCat.name;
      } else if (firstCat && firstCat.slug) {
        catName = firstCat.slug;
      } else if (firstCat && firstCat._id) {
        catName = firstCat._id;
      }
      
      if (catName) {
        return normalizeCategory(catName);
      }
    }
  }
  
  // 3. Depuis _category_slug (défini par le filtre before_post_render)
  if (post._category_slug) {
    return post._category_slug;
  }
  
  // 4. Depuis le chemin du fichier
  if (post.source) {
    return getCategoryFromPath(post.source);
  }
  
  return null;
}

/**
 * Normalise un tag
 */
function normalizeTag(tag) {
  if (!tag || typeof tag !== 'string') return null;
  
  let normalized = tag.trim();
  
  if (TAG_RENAMES[normalized]) {
    normalized = TAG_RENAMES[normalized];
  }
  
  if (TAGS_TO_REMOVE.has(normalized.toLowerCase())) {
    return null;
  }
  
  return normalized;
}

/**
 * Traite et normalise une liste de tags
 */
function processTags(tags) {
  if (!tags) return [];
  
  let tagArray = [];
  
  if (Array.isArray(tags)) {
    tagArray = tags;
  } else if (typeof tags === 'string') {
    tagArray = tags.split(',').map(t => t.trim());
  } else if (tags.toArray) {
    tagArray = tags.toArray().map(t => t.name || t);
  } else if (typeof tags.forEach === 'function') {
    tags.forEach(t => tagArray.push(t.name || t));
  }
  
  const normalized = new Set();
  tagArray.forEach(tag => {
    const norm = normalizeTag(typeof tag === 'object' ? tag.name : String(tag));
    if (norm) {
      normalized.add(norm);
    }
  });
  
  return Array.from(normalized);
}

// ═══════════════════════════════════════════════════════════════════════════
// FILTRE HEXO - Avant le rendu
// ═══════════════════════════════════════════════════════════════════════════

hexo.extend.filter.register('before_post_render', function(data) {
  // 1. Détection et stockage de la catégorie
  const detectedCategory = getPostCategory(data);
  if (detectedCategory) {
    // Stocker dans une propriété custom (category peut être read-only)
    data._category_slug = detectedCategory;
    data._category_info = getCategoryInfo(detectedCategory);
    
    // Si category n'est pas défini, essayer de le définir
    if (!data.category) {
      try {
        data.category = detectedCategory;
      } catch (e) {
        // Ignorer si read-only
      }
    }
  }
  
  // 2. Normalisation des tags
  if (data.tags && data.tags.length) {
    data.normalized_tags = processTags(data.tags);
  }
  
  return data;
});

// ═══════════════════════════════════════════════════════════════════════════
// HELPERS HEXO
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Helper: get_category_info(slug)
 */
hexo.extend.helper.register('get_category_info', function(slug) {
  return getCategoryInfo(slug);
});

/**
 * Helper: get_all_categories()
 * Retourne toutes les catégories définies
 */
hexo.extend.helper.register('get_all_categories', function() {
  return Object.keys(CATEGORIES).map(slug => ({
    ...CATEGORIES[slug],
    slug
  }));
});

/**
 * Helper: get_post_category(post)
 * Retourne le slug de la catégorie d'un post
 */
hexo.extend.helper.register('get_post_category', function(post) {
  if (post._category_slug) return post._category_slug;
  return getPostCategory(post);
});

/**
 * Helper: get_post_category_info(post)
 * Retourne les infos complètes de la catégorie d'un post
 */
hexo.extend.helper.register('get_post_category_info', function(post) {
  if (post._category_info) return post._category_info;
  const slug = getPostCategory(post);
  return getCategoryInfo(slug);
});

/**
 * Helper: get_normalized_tags(post)
 */
hexo.extend.helper.register('get_normalized_tags', function(post) {
  if (post.normalized_tags && post.normalized_tags.length) {
    return post.normalized_tags;
  }
  return processTags(post.tags);
});

/**
 * Helper: get_posts_by_category(categorySlug)
 * Retourne tous les posts d'une catégorie
 * 
 * IMPORTANT: Dans Hexo, site.posts.filter() retourne un Query object
 * On doit itérer manuellement pour un filtrage fiable
 */
hexo.extend.helper.register('get_posts_by_category', function(categorySlug) {
  const site = this.site;
  if (!site || !site.posts || !site.posts.length) {
    return [];
  }
  
  const targetSlug = normalizeCategory(categorySlug);
  if (!targetSlug) {
    return [];
  }
  
  // Convertir en array et filtrer manuellement
  const allPosts = site.posts.toArray();
  const filtered = [];
  
  allPosts.forEach(function(post) {
    const postCat = getPostCategory(post);
    if (postCat && postCat.toLowerCase() === targetSlug.toLowerCase()) {
      filtered.push(post);
    }
  });
  
  // Trier par date décroissante
  filtered.sort(function(a, b) {
    return new Date(b.date) - new Date(a.date);
  });
  
  return filtered;
});

/**
 * Helper: count_posts_in_category(categorySlug)
 */
hexo.extend.helper.register('count_posts_in_category', function(categorySlug) {
  const site = this.site;
  if (!site || !site.posts || !site.posts.length) {
    return 0;
  }
  
  const targetSlug = normalizeCategory(categorySlug);
  if (!targetSlug) {
    return 0;
  }
  
  const allPosts = site.posts.toArray();
  let count = 0;
  
  allPosts.forEach(function(post) {
    const postCat = getPostCategory(post);
    if (postCat && postCat.toLowerCase() === targetSlug.toLowerCase()) {
      count++;
    }
  });
  
  return count;
});

// ═══════════════════════════════════════════════════════════════════════════
// GÉNÉRATEUR - API JSON des catégories
// ═══════════════════════════════════════════════════════════════════════════

hexo.extend.generator.register('categories_api', function(locals) {
  const categoryCounts = {};
  
  locals.posts.forEach(function(post) {
    const catSlug = getPostCategory(post);
    if (catSlug) {
      categoryCounts[catSlug] = (categoryCounts[catSlug] || 0) + 1;
    }
  });
  
  const categories = Object.keys(CATEGORIES).map(slug => ({
    ...CATEGORIES[slug],
    slug,
    count: categoryCounts[slug] || 0
  }));
  
  return {
    path: 'api/categories.json',
    data: JSON.stringify({ categories, counts: categoryCounts }, null, 2)
  };
});

// ═══════════════════════════════════════════════════════════════════════════
// CONSOLE COMMAND - Debug des catégories
// ═══════════════════════════════════════════════════════════════════════════

hexo.extend.console.register('debug-categories', 'Affiche les catégories détectées pour chaque post', {}, function(args) {
  const posts = this.locals.get('posts');
  
  console.log('\n═══════════════════════════════════════════════════════════════');
  console.log('🔍 DEBUG CATÉGORIES');
  console.log('═══════════════════════════════════════════════════════════════\n');
  
  const byCategory = {};
  
  posts.forEach(post => {
    const cat = getPostCategory(post);
    const catDisplay = cat || '(aucune)';
    
    if (!byCategory[catDisplay]) {
      byCategory[catDisplay] = [];
    }
    byCategory[catDisplay].push({
      title: post.title,
      source: post.source,
      frontMatterCat: post.category,
      frontMatterCats: post.categories ? (post.categories.toArray ? post.categories.toArray().map(c => c.name) : post.categories) : []
    });
  });
  
  Object.keys(byCategory).sort().forEach(cat => {
    const catInfo = getCategoryInfo(cat);
    console.log(`\n${catInfo.icon || '📁'} ${cat.toUpperCase()} (${byCategory[cat].length} posts)`);
    console.log('─'.repeat(50));
    byCategory[cat].forEach(p => {
      console.log(`  • ${p.title}`);
      console.log(`    source: ${p.source}`);
      if (p.frontMatterCat) console.log(`    category: ${p.frontMatterCat}`);
      if (p.frontMatterCats.length) console.log(`    categories: [${p.frontMatterCats.join(', ')}]`);
    });
  });
  
  console.log('\n═══════════════════════════════════════════════════════════════');
  console.log(`Total: ${posts.length} posts`);
  console.log('═══════════════════════════════════════════════════════════════\n');
});

// ═══════════════════════════════════════════════════════════════════════════
// LOG D'INITIALISATION
// ═══════════════════════════════════════════════════════════════════════════

hexo.log.info('[auto-category-tags] Plugin chargé');
hexo.log.info(`  → ${Object.keys(CATEGORIES).length} catégories définies`);
hexo.log.info(`  → ${Object.keys(CATEGORY_ALIASES).length} aliases`);
hexo.log.info(`  → Commande disponible: hexo debug-categories`);
