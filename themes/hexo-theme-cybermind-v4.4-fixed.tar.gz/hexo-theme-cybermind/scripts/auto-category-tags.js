/**
 * ═══════════════════════════════════════════════════════════════════════════
 * auto-category-tags.js - Gestion automatique des catégories et tags
 * ═══════════════════════════════════════════════════════════════════════════
 * 
 * Ce script Hexo:
 * 1. Détecte automatiquement la catégorie depuis le chemin du fichier
 * 2. Normalise et corrige les tags
 * 3. Supprime les tags inutilisés/orphelins
 * 4. Fusionne les tags similaires
 * 
 * Installation: Copier dans themes/cybermind/scripts/
 * 
 * ═══════════════════════════════════════════════════════════════════════════
 */

'use strict';

const path = require('path');

// ═══════════════════════════════════════════════════════════════════════════
// CONFIGURATION
// ═══════════════════════════════════════════════════════════════════════════

// Mapping des dossiers vers les catégories
const FOLDER_TO_CATEGORY = {
  'cybersecurity': { name: 'Cybersécurité', slug: 'cybersecurity', color: '#00ff88', icon: '🛡️' },
  'embedded': { name: 'Embarqué', slug: 'embedded', color: '#ff6600', icon: '⚙️' },
  'linux': { name: 'Linux', slug: 'linux', color: '#ffcc00', icon: '🐧' },
  'creative': { name: 'Créativité', slug: 'creative', color: '#ff6699', icon: '🎨' },
  'philosophy': { name: 'Philosophie', slug: 'philosophy', color: '#9966ff', icon: '🧘' },
  'tutorials': { name: 'Tutoriels', slug: 'tutorials', color: '#66ccff', icon: '📖' },
  // Aliases
  'security': { name: 'Cybersécurité', slug: 'cybersecurity', color: '#00ff88', icon: '🛡️' },
  'cyber': { name: 'Cybersécurité', slug: 'cybersecurity', color: '#00ff88', icon: '🛡️' },
  'arm': { name: 'Embarqué', slug: 'embedded', color: '#ff6600', icon: '⚙️' },
  'hardware': { name: 'Embarqué', slug: 'embedded', color: '#ff6600', icon: '⚙️' },
  'art': { name: 'Créativité', slug: 'creative', color: '#ff6699', icon: '🎨' },
  'yijing': { name: 'Philosophie', slug: 'philosophy', color: '#9966ff', icon: '🧘' },
  'yi-jing': { name: 'Philosophie', slug: 'philosophy', color: '#9966ff', icon: '🧘' },
  'howto': { name: 'Tutoriels', slug: 'tutorials', color: '#66ccff', icon: '📖' },
  'guides': { name: 'Tutoriels', slug: 'tutorials', color: '#66ccff', icon: '📖' },
};

// Tags à renommer (normalisation)
const TAG_RENAMES = {
  // Casse et accents
  'CrowdSec': 'crowdsec',
  'OpenWrt': 'openwrt',
  'Armbian': 'armbian',
  'RaspberryPi': 'raspberry-pi',
  'Raspberry Pi': 'raspberry-pi',
  'raspberry pi': 'raspberry-pi',
  'Yi Jing': 'yi-jing',
  'yi jing': 'yi-jing',
  'yijing': 'yi-jing',
  'Yi-Jing': 'yi-jing',
  'JavaScript': 'javascript',
  'Python': 'python',
  'python3': 'python',
  
  // Corrections orthographiques
  'securite': 'sécurité',
  'securité': 'sécurité',
  'geometrie': 'géométrie',
  'creatif': 'créatif',
  
  // Fusions de tags similaires
  'linux-kernel': 'kernel',
  'kernel-linux': 'kernel',
  'cyber-securite': 'cybersécurité',
  'cyber-security': 'cybersécurité',
  'infosec': 'cybersécurité',
  'art-generatif': 'art-génératif',
  'generative-art': 'art-génératif',
};

// Tags à supprimer (trop génériques ou inutiles)
const TAGS_TO_REMOVE = new Set([
  'misc', 'divers', 'other', 'test', 'draft', 'todo', 'wip', 'temp',
  'uncategorized', 'none', 'undefined', 'null', ''
]);

// ═══════════════════════════════════════════════════════════════════════════
// FONCTIONS UTILITAIRES
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Extrait la catégorie depuis le chemin du fichier
 * Ex: source/blog/cybersecurity/mon-article.md → cybersecurity
 */
function getCategoryFromPath(filePath) {
  if (!filePath) return null;
  
  const parts = filePath.split(path.sep);
  
  // Chercher dans les parties du chemin
  for (let i = 0; i < parts.length; i++) {
    const part = parts[i].toLowerCase();
    
    // Si on trouve "blog", la catégorie est le dossier suivant
    if (part === 'blog' && i + 1 < parts.length) {
      const nextPart = parts[i + 1].toLowerCase();
      // Vérifier que ce n'est pas le fichier lui-même
      if (!nextPart.endsWith('.md')) {
        return FOLDER_TO_CATEGORY[nextPart] || { name: nextPart, slug: nextPart };
      }
    }
    
    // Sinon chercher directement dans le mapping
    if (FOLDER_TO_CATEGORY[part]) {
      return FOLDER_TO_CATEGORY[part];
    }
  }
  
  return null;
}

/**
 * Normalise un tag
 */
function normalizeTag(tag) {
  if (!tag || typeof tag !== 'string') return null;
  
  let normalized = tag.trim();
  
  // Appliquer les renommages
  if (TAG_RENAMES[normalized]) {
    normalized = TAG_RENAMES[normalized];
  }
  
  // Supprimer si dans la liste noire
  if (TAGS_TO_REMOVE.has(normalized.toLowerCase())) {
    return null;
  }
  
  return normalized;
}

/**
 * Traite et normalise une liste de tags
 */
function processTags(tags) {
  if (!tags) return [];
  
  // Convertir en array si nécessaire
  let tagArray = [];
  if (Array.isArray(tags)) {
    tagArray = tags;
  } else if (typeof tags === 'string') {
    tagArray = tags.split(',').map(t => t.trim());
  } else if (tags.toArray) {
    tagArray = tags.toArray().map(t => t.name || t);
  }
  
  // Normaliser et dédupliquer
  const normalized = new Set();
  tagArray.forEach(tag => {
    const norm = normalizeTag(typeof tag === 'object' ? tag.name : tag);
    if (norm) {
      normalized.add(norm);
    }
  });
  
  return Array.from(normalized);
}

// ═══════════════════════════════════════════════════════════════════════════
// FILTRE HEXO - Avant le rendu
// ═══════════════════════════════════════════════════════════════════════════

hexo.extend.filter.register('before_post_render', function(data) {
  // 1. Détection automatique de la catégorie depuis le chemin
  if (!data.category && data.source) {
    const detectedCat = getCategoryFromPath(data.source);
    if (detectedCat) {
      data.category = detectedCat.slug;
      data._auto_category = detectedCat; // Stocker les infos complètes
      
      // Log en mode debug
      if (hexo.env.debug) {
        hexo.log.debug(`[auto-category] ${data.source} → ${detectedCat.slug}`);
      }
    }
  }
  
  // 2. Normalisation des tags - Stocker dans une propriété custom
  // Note: data.tags est en lecture seule dans Hexo, on ne peut pas le modifier
  if (data.tags && data.tags.length) {
    const normalizedTags = processTags(data.tags);
    // Stocker les tags normalisés dans une propriété accessible
    data.normalized_tags = normalizedTags;
    
    // Log en mode debug
    if (hexo.env.debug) {
      hexo.log.debug(`[auto-tags] ${data.title}: ${normalizedTags.length} tags normalized`);
    }
  }
  
  // 3. Ajouter les métadonnées de catégorie si disponibles
  if (data._auto_category) {
    data.category_color = data._auto_category.color;
    data.category_icon = data._auto_category.icon;
    data.category_name = data._auto_category.name;
  }
  
  return data;
});

// ═══════════════════════════════════════════════════════════════════════════
// HELPER HEXO - Accès aux infos de catégorie
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Helper: get_category_info(slug)
 * Usage dans les templates: <%- get_category_info('cybersecurity') %>
 */
hexo.extend.helper.register('get_category_info', function(slug) {
  return FOLDER_TO_CATEGORY[slug] || { name: slug, slug: slug, color: '#888888', icon: '📁' };
});

/**
 * Helper: get_category_from_path(path)
 * Usage: <%- get_category_from_path(page.source) %>
 */
hexo.extend.helper.register('get_category_from_path', function(filePath) {
  return getCategoryFromPath(filePath);
});

/**
 * Helper: normalize_tags(tags)
 * Usage: <%- normalize_tags(page.tags) %>
 * Retourne un array de strings normalisés
 */
hexo.extend.helper.register('normalize_tags', function(tags) {
  return processTags(tags);
});

/**
 * Helper: get_normalized_tags(post)
 * Usage: <% get_normalized_tags(post).forEach(tag => { %>
 * Retourne les tags normalisés d'un post (utilise normalized_tags si disponible)
 */
hexo.extend.helper.register('get_normalized_tags', function(post) {
  if (post.normalized_tags && post.normalized_tags.length) {
    return post.normalized_tags;
  }
  return processTags(post.tags);
});

/**
 * Helper: get_posts_by_category(categorySlug)
 * Usage: <% get_posts_by_category('cybersecurity').forEach(post => { %>
 */
hexo.extend.helper.register('get_posts_by_category', function(categorySlug) {
  const site = this.site;
  if (!site || !site.posts) return [];
  
  return site.posts.filter(function(post) {
    // Vérifier le champ category
    if (post.category === categorySlug) return true;
    
    // Vérifier dans categories
    if (post.categories && post.categories.length) {
      return post.categories.some(function(cat) {
        return cat.slug === categorySlug || cat.name.toLowerCase() === categorySlug;
      });
    }
    
    // Vérifier dans le chemin
    if (post.source) {
      const detected = getCategoryFromPath(post.source);
      if (detected && detected.slug === categorySlug) return true;
    }
    
    return false;
  }).sort('date', -1);
});

// ═══════════════════════════════════════════════════════════════════════════
// GÉNÉRATEUR - Liste des catégories disponibles
// ═══════════════════════════════════════════════════════════════════════════

hexo.extend.generator.register('category_data', function(locals) {
  // Compter les posts par catégorie
  const categoryCounts = {};
  
  locals.posts.forEach(function(post) {
    let catSlug = post.category;
    
    // Détecter depuis le chemin si pas défini
    if (!catSlug && post.source) {
      const detected = getCategoryFromPath(post.source);
      if (detected) catSlug = detected.slug;
    }
    
    if (catSlug) {
      categoryCounts[catSlug] = (categoryCounts[catSlug] || 0) + 1;
    }
  });
  
  // Construire les données
  const categories = Object.keys(FOLDER_TO_CATEGORY)
    .filter(key => !['security', 'cyber', 'arm', 'hardware', 'art', 'yijing', 'yi-jing', 'howto', 'guides'].includes(key))
    .map(slug => ({
      ...FOLDER_TO_CATEGORY[slug],
      count: categoryCounts[slug] || 0
    }));
  
  // Générer un fichier JSON avec les données
  return {
    path: 'api/categories.json',
    data: JSON.stringify({ categories, counts: categoryCounts }, null, 2)
  };
});

// ═══════════════════════════════════════════════════════════════════════════
// CONSOLE COMMAND - Audit des tags
// ═══════════════════════════════════════════════════════════════════════════

hexo.extend.console.register('tags-audit', 'Audit des tags du blog', {}, function(args) {
  const posts = this.locals.get('posts');
  const tagCounts = {};
  const tagFiles = {};
  
  posts.forEach(post => {
    if (post.tags) {
      post.tags.forEach(tag => {
        const name = tag.name || tag;
        tagCounts[name] = (tagCounts[name] || 0) + 1;
        if (!tagFiles[name]) tagFiles[name] = [];
        tagFiles[name].push(post.source);
      });
    }
  });
  
  console.log('\n═══════════════════════════════════════════════════════════════');
  console.log('🏷️  AUDIT DES TAGS');
  console.log('═══════════════════════════════════════════════════════════════\n');
  
  // Tags les plus utilisés
  console.log('📊 Tags les plus utilisés:');
  Object.entries(tagCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 15)
    .forEach(([tag, count]) => {
      console.log(`   ${tag}: ${count}`);
    });
  
  // Tags orphelins (1 seule utilisation)
  const orphans = Object.entries(tagCounts).filter(([_, count]) => count === 1);
  if (orphans.length > 0) {
    console.log(`\n👻 Tags orphelins (${orphans.length}):`);
    orphans.slice(0, 20).forEach(([tag, _]) => {
      console.log(`   - ${tag} → ${tagFiles[tag][0]}`);
    });
    if (orphans.length > 20) {
      console.log(`   ... et ${orphans.length - 20} autres`);
    }
  }
  
  // Tags à renommer
  const toRename = Object.keys(tagCounts).filter(tag => TAG_RENAMES[tag]);
  if (toRename.length > 0) {
    console.log(`\n✏️  Tags à renommer (${toRename.length}):`);
    toRename.forEach(tag => {
      console.log(`   ${tag} → ${TAG_RENAMES[tag]}`);
    });
  }
  
  // Tags à supprimer
  const toRemove = Object.keys(tagCounts).filter(tag => TAGS_TO_REMOVE.has(tag.toLowerCase()));
  if (toRemove.length > 0) {
    console.log(`\n🗑️  Tags à supprimer (${toRemove.length}):`);
    toRemove.forEach(tag => {
      console.log(`   - ${tag}`);
    });
  }
  
  console.log('\n═══════════════════════════════════════════════════════════════');
  console.log(`Total: ${Object.keys(tagCounts).length} tags uniques`);
  console.log('═══════════════════════════════════════════════════════════════\n');
});

// ═══════════════════════════════════════════════════════════════════════════
// LOG D'INITIALISATION
// ═══════════════════════════════════════════════════════════════════════════

hexo.log.info('[auto-category-tags] Plugin chargé');
hexo.log.info(`  → ${Object.keys(FOLDER_TO_CATEGORY).length} mappings de catégories`);
hexo.log.info(`  → ${Object.keys(TAG_RENAMES).length} règles de renommage de tags`);
